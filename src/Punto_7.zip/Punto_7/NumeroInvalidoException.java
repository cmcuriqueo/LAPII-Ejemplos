package Punto_7;

public class NumeroInvalidoException extends RuntimeException {
	public NumeroInvalidoException(String message) {
		super(message);
	}
}
