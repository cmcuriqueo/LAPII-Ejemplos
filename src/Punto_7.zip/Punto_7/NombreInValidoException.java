package Punto_7;

public class NombreInValidoException extends RuntimeException {
	public NombreInValidoException(String message) {
		super(message);
	}
}
